// DisasterX - Enterprise Emergency Response Platform Logic
// Google Maps GIS Engine & OpenGPS Real-Time Location

class DisasterXApp {
  constructor() {
    this.incidents = [];
    this.currentView = "home";
    this.userRole = "admin";
    this.currentUser = { name: "Harshan Krishna", email: "admin@disasterx.org", role: "admin" };
    
    // GPS & Coordinates
    this.userRealtimeCoords = [13.0827, 80.2707];
    this.pickerCoords = [13.0827, 80.2707];
    
    // Google Maps Key state
    this.googleApiKey = localStorage.getItem("disasterx_gmaps_key") || "";
    this.googleMapsLoaded = false;
    this.googleMapInstance = null;
    this.googlePickerMapInstance = null;
    this.googleMarkers = [];

    // Leaflet Maps Fallback
    this.homeMap = null;
    this.homeMarkers = [];
    this.fullGisMap = null;
    this.fullGisMarkers = [];
    this.pickerMap = null;
    this.pickerMarker = null;

    // Filters
    this.filterCategory = "All";
    this.filterSeverity = "All";

    // Upload & AI Piracy Detection
    this.uploadedPhotoData = null;
    this.aiVerificationResult = null;

    // Charts
    this.categoryChart = null;
    this.severityChart = null;

    this.init();
  }

  init() {
    initializeLocalStorageData();
    this.loadIncidents();
    this.bindEvents();
    this.setupViewNavigation();
    
    // If user has a saved Google Maps API key, load it dynamically
    if (this.googleApiKey) {
      this.loadGoogleMapsScript(this.googleApiKey);
    }

    this.acquireRealtimeGpsLocation();
    this.renderHome();
    this.updateUserSessionUI();
    this.initFloatingAi();
  }

  // Load Google Maps API Dynamically
  loadGoogleMapsScript(apiKey) {
    if (!apiKey) return;
    this.googleApiKey = apiKey;
    localStorage.setItem("disasterx_gmaps_key", apiKey);

    if (window.google && window.google.maps) {
      this.googleMapsLoaded = true;
      this.refreshAllMaps();
      return;
    }

    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places,geometry&callback=onGoogleMapsInit`;
    script.async = true;
    script.defer = true;
    window.onGoogleMapsInit = () => {
      this.googleMapsLoaded = true;
      console.log("Google Maps API successfully initialized.");
      this.refreshAllMaps();
      const indicator = document.getElementById("gmaps-engine-badge");
      if (indicator) {
        indicator.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1 inline-block"></span> Google Maps API Active`;
        indicator.className = "badge-clean badge-clean-low";
      }
    };
    script.onerror = () => {
      console.warn("Google Maps script failed to load, keeping Leaflet OpenGPS engine active.");
      alert("Notice: Google Maps API key verification pending or restricted. System running on high-precision OpenGPS GIS.");
    };
    document.head.appendChild(script);
  }

  // Prompt / Set Google Maps API Key
  promptGoogleApiKey() {
    const key = prompt("Enter your Google Maps JavaScript API Key:", this.googleApiKey);
    if (key !== null) {
      const cleanKey = key.trim();
      if (cleanKey) {
        this.loadGoogleMapsScript(cleanKey);
        alert("Google Maps API key saved. Initializing live satellite GIS layer.");
      } else {
        localStorage.removeItem("disasterx_gmaps_key");
        this.googleApiKey = "";
        this.googleMapsLoaded = false;
        alert("Switched to built-in OpenGPS engine.");
        this.refreshAllMaps();
      }
    }
  }

  // Real-Time OpenGPS Acquisition
  acquireRealtimeGpsLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          this.userRealtimeCoords = [lat, lng];
          this.pickerCoords = [lat, lng];

          this.recenterIncidentsToCoordinates(lat, lng);
          this.refreshAllMaps();
          this.reverseGeocode(lat, lng);

          const statusIndicator = document.getElementById("gps-status-indicator");
          if (statusIndicator) {
            statusIndicator.innerHTML = `Live GPS: ${lat.toFixed(4)}, ${lng.toFixed(4)} (±${Math.round(pos.coords.accuracy)}m)`;
            statusIndicator.className = "text-[10px] text-emerald-400 font-mono";
          }
        },
        () => {
          this.recenterIncidentsToCoordinates(this.userRealtimeCoords[0], this.userRealtimeCoords[1]);
          this.refreshAllMaps();
        },
        { enableHighAccuracy: true, timeout: 6000 }
      );
    } else {
      this.recenterIncidentsToCoordinates(this.userRealtimeCoords[0], this.userRealtimeCoords[1]);
      this.refreshAllMaps();
    }
  }

  recenterIncidentsToCoordinates(baseLat, baseLng) {
    const offsets = [
      [0.008, 0.012],
      [-0.011, -0.009],
      [0.014, -0.015],
      [-0.007, 0.018],
      [0.019, 0.005],
      [-0.015, -0.018]
    ];

    this.incidents.forEach((inc, index) => {
      if (offsets[index]) {
        inc.coordinates = [
          Number((baseLat + offsets[index][0]).toFixed(5)),
          Number((baseLng + offsets[index][1]).toFixed(5))
        ];
      }
    });

    localStorage.setItem("disasterx_incidents", JSON.stringify(this.incidents));
  }

  loadIncidents() {
    try {
      const stored = localStorage.getItem("disasterx_incidents");
      this.incidents = stored ? JSON.parse(stored) : [...INITIAL_INCIDENTS];
    } catch (e) {
      this.incidents = [...INITIAL_INCIDENTS];
    }
  }

  saveIncidents() {
    localStorage.setItem("disasterx_incidents", JSON.stringify(this.incidents));
    this.renderAdminStats();
    this.refreshAllMaps();
    if (this.currentView === "admin") this.renderAdminTable();
  }

  setupViewNavigation() {
    document.querySelectorAll("[data-nav]").forEach(link => {
      link.addEventListener("click", (e) => {
        e.preventDefault();
        const targetView = link.getAttribute("data-nav");
        this.switchView(targetView);
        document.getElementById("mobile-menu")?.classList.add("hidden");
      });
    });
  }

  switchView(viewName) {
    this.currentView = viewName;
    window.scrollTo({ top: 0, behavior: "smooth" });

    document.querySelectorAll("[data-nav]").forEach(el => {
      if (el.getAttribute("data-nav") === viewName) {
        el.classList.add("text-white", "font-semibold");
        el.classList.remove("text-slate-400");
      } else {
        el.classList.remove("text-white", "font-semibold");
        el.classList.add("text-slate-400");
      }
    });

    document.querySelectorAll(".view-section").forEach(sec => sec.classList.add("hidden"));
    const targetEl = document.getElementById(`view-${viewName}`);
    if (targetEl) targetEl.classList.remove("hidden");

    if (viewName === "home") {
      this.renderHome();
      setTimeout(() => this.initHomeMap(), 50);
    } else if (viewName === "report") {
      this.renderReportForm();
    } else if (viewName === "gis") {
      setTimeout(() => this.initFullGisMap(), 50);
    } else if (viewName === "admin") {
      this.renderAdminStats();
      this.renderAdminTable();
      setTimeout(() => this.initDashboardCharts(), 50);
    }

    if (window.lucide) window.lucide.createIcons();
  }

  renderHome() {
    const categoryGrid = document.getElementById("home-category-grid");
    if (categoryGrid) {
      categoryGrid.innerHTML = EMERGENCY_CATEGORIES.map(cat => {
        const catCount = this.incidents.filter(i => i.category === cat.id && i.status !== "Resolved").length;
        return `
          <div onclick="app.quickFilterByCategory('${cat.id}')" class="clean-card clean-card-hover p-3.5 cursor-pointer flex flex-col justify-between">
            <div class="flex items-center space-x-2.5">
              <div class="p-2 rounded-lg text-white" style="background-color: ${cat.color}20;">
                <i data-lucide="${cat.icon}" class="w-4 h-4" style="color: ${cat.color};"></i>
              </div>
              <h4 class="text-xs font-semibold text-white">${cat.name}</h4>
            </div>
            <div class="mt-3 flex items-center justify-between text-[11px] text-slate-400">
              <span>${catCount} active</span>
              <span class="text-sky-400">&rarr;</span>
            </div>
          </div>
        `;
      }).join("");
    }

    const recentFeed = document.getElementById("home-recent-incidents");
    if (recentFeed) {
      recentFeed.innerHTML = this.incidents.slice(0, 3).map(inc => `
        <div class="clean-card p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div class="flex items-start space-x-3">
            <span class="w-2 h-2 rounded-full mt-1.5 ${inc.severity === 'Critical' ? 'bg-red-500' : 'bg-amber-400'}"></span>
            <div>
              <div class="flex items-center space-x-2">
                <span class="text-[10px] font-mono text-slate-400">${inc.id}</span>
                <span class="badge-clean ${this.getSeverityBadgeClass(inc.severity)}">${inc.severity}</span>
                <span class="text-[10px] text-slate-500 font-mono">${this.formatTimeAgo(inc.timestamp)}</span>
              </div>
              <h4 class="text-xs font-semibold text-white mt-0.5">${inc.title}</h4>
              <p class="text-[11px] text-slate-400">${inc.location}</p>
            </div>
          </div>
          <button onclick="app.showIncidentDetail('${inc.id}')" class="btn-pill-dark text-xs self-start sm:self-center py-1 px-3">
            Inspect Dossier
          </button>
        </div>
      `).join("");
    }

    if (window.lucide) window.lucide.createIcons();
  }

  formatTimeAgo(dateString) {
    const diff = Math.floor((new Date() - new Date(dateString)) / 1000);
    if (diff < 60) return "just now";
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  }

  getSeverityBadgeClass(severity) {
    switch (severity) {
      case "Critical": return "badge-clean-critical";
      case "High": return "badge-clean-high";
      case "Medium": return "badge-clean-medium";
      default: return "badge-clean-low";
    }
  }

  // MAP 1: Home Map
  initHomeMap() {
    const container = document.getElementById("command-center-map");
    if (!container) return;

    if (this.googleMapsLoaded && window.google && window.google.maps) {
      this.initGoogleHomeMap(container);
      return;
    }

    if (!this.homeMap) {
      this.homeMap = L.map("command-center-map", {
        zoomControl: true,
        attributionControl: false
      }).setView(this.userRealtimeCoords, 13);

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19
      }).addTo(this.homeMap);
    } else {
      this.homeMap.invalidateSize();
    }

    this.renderMarkersOnMap(this.homeMap, "home");
    this.renderGisIncidentQueue();
  }

  initGoogleHomeMap(container) {
    const center = { lat: this.userRealtimeCoords[0], lng: this.userRealtimeCoords[1] };
    this.googleMapInstance = new google.maps.Map(container, {
      center: center,
      zoom: 13,
      disableDefaultUI: false,
      styles: [
        { elementType: "geometry", stylers: [{ color: "#0B1120" }] },
        { elementType: "labels.text.stroke", stylers: [{ color: "#0B1120" }] },
        { elementType: "labels.text.fill", stylers: [{ color: "#94A3B8" }] },
        { featureType: "road", elementType: "geometry", stylers: [{ color: "#1E293B" }] },
        { featureType: "water", elementType: "geometry", stylers: [{ color: "#060913" }] }
      ]
    });

    // Real-time GPS user marker
    new google.maps.Marker({
      position: center,
      map: this.googleMapInstance,
      title: "Your Real-Time Location",
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 8,
        fillColor: "#38BDF8",
        fillOpacity: 1,
        strokeWeight: 3,
        strokeColor: "#FFFFFF"
      }
    });

    // Incident markers
    this.incidents.forEach(inc => {
      const pos = { lat: inc.coordinates[0], lng: inc.coordinates[1] };
      const marker = new google.maps.Marker({
        position: pos,
        map: this.googleMapInstance,
        title: inc.title,
        icon: {
          path: google.maps.SymbolPath.BACKWARD_CLOSED_ARROW,
          scale: 5,
          fillColor: inc.severity === "Critical" ? "#EF4444" : "#F59E0B",
          fillOpacity: 1,
          strokeWeight: 1,
          strokeColor: "#FFFFFF"
        }
      });
      marker.addListener("click", () => this.selectIncidentForGisPanel(inc.id));
    });
  }

  // MAP 2: Full Screen GIS Map
  initFullGisMap() {
    const container = document.getElementById("command-center-map-full");
    if (!container) return;

    if (this.googleMapsLoaded && window.google && window.google.maps) {
      this.initGoogleHomeMap(container);
      return;
    }

    if (!this.fullGisMap) {
      this.fullGisMap = L.map("command-center-map-full", {
        zoomControl: true,
        attributionControl: false
      }).setView(this.userRealtimeCoords, 13);

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19
      }).addTo(this.fullGisMap);
    } else {
      this.fullGisMap.invalidateSize();
    }

    this.renderMarkersOnMap(this.fullGisMap, "full");
    if (this.incidents.length > 0) this.selectIncidentForGisPanel(this.incidents[0].id);
  }

  renderMarkersOnMap(mapInstance, mapType) {
    if (!mapInstance) return;

    if (mapType === "home") {
      this.homeMarkers.forEach(m => mapInstance.removeLayer(m));
      this.homeMarkers = [];
    } else {
      this.fullGisMarkers.forEach(m => mapInstance.removeLayer(m));
      this.fullGisMarkers = [];
    }

    // Live User GPS Pin
    const liveIcon = L.divIcon({
      className: "user-live-wrapper",
      html: `<div class="user-live-marker" title="Your Live Real-Time Location"></div>`,
      iconSize: [20, 20],
      iconAnchor: [10, 10]
    });

    const userMarker = L.marker(this.userRealtimeCoords, { icon: liveIcon })
      .addTo(mapInstance)
      .bindPopup(`<div class="p-1 text-xs"><strong>Your Real-Time Location</strong><br/>Live Signal Active</div>`);

    if (mapType === "home") this.homeMarkers.push(userMarker);
    else this.fullGisMarkers.push(userMarker);

    // Incidents
    this.incidents.forEach(inc => {
      if (!inc.coordinates || inc.coordinates.length !== 2) return;

      const markerClass = inc.severity === "Critical" ? "clean-marker-critical" : inc.severity === "High" ? "clean-marker-high" : inc.severity === "Medium" ? "clean-marker-medium" : "clean-marker-low";
      const iconName = inc.category === "Fire Emergency" ? "flame" : inc.category === "Road Accident" ? "car" : inc.category === "Medical Emergency" ? "heart-pulse" : "alert-triangle";

      const pinIcon = L.divIcon({
        className: "custom-marker-wrapper",
        html: `<div class="clean-marker ${markerClass}"><i data-lucide="${iconName}" class="w-3.5 h-3.5"></i></div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });

      const marker = L.marker(inc.coordinates, { icon: pinIcon }).addTo(mapInstance);
      marker.bindPopup(`
        <div style="min-width: 180px">
          <div class="flex items-center justify-between pb-1 border-b border-slate-700">
            <span class="text-[10px] font-mono text-slate-400">${inc.id}</span>
            <span class="badge-clean ${this.getSeverityBadgeClass(inc.severity)}">${inc.severity}</span>
          </div>
          <h4 class="text-xs font-semibold text-white mt-1">${inc.title}</h4>
          <p class="text-[11px] text-slate-400 mt-0.5">${inc.location}</p>
          <div class="mt-2 pt-1 border-t border-slate-800 flex justify-between items-center text-[11px]">
            <span class="text-slate-400">${inc.peopleAffected} affected</span>
            <button onclick="app.showIncidentDetail('${inc.id}')" class="text-sky-400 hover:underline">Details &rarr;</button>
          </div>
        </div>
      `);

      marker.on("click", () => this.selectIncidentForGisPanel(inc.id));

      if (mapType === "home") this.homeMarkers.push(marker);
      else this.fullGisMarkers.push(marker);
    });

    if (window.lucide) window.lucide.createIcons();
  }

  refreshAllMaps() {
    if (this.homeMap) {
      this.homeMap.setView(this.userRealtimeCoords, 13);
      this.renderMarkersOnMap(this.homeMap, "home");
      this.renderGisIncidentQueue();
    }
    if (this.fullGisMap) {
      this.fullGisMap.setView(this.userRealtimeCoords, 13);
      this.renderMarkersOnMap(this.fullGisMap, "full");
    }
    if (this.pickerMap && this.pickerMarker) {
      this.pickerMap.setView(this.pickerCoords, 14);
      this.pickerMarker.setLatLng(this.pickerCoords);
    }
  }

  renderGisIncidentQueue() {
    const queueList = document.getElementById("gis-incident-queue");
    if (!queueList) return;

    queueList.innerHTML = this.incidents.map(inc => `
      <div onclick="app.selectIncidentForGisPanel('${inc.id}')" class="p-2.5 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-900/60 hover:bg-slate-900 cursor-pointer transition space-y-1">
        <div class="flex items-center justify-between">
          <span class="text-xs font-medium text-white font-mono">${inc.reporterContact || inc.id}</span>
          <span class="badge-clean ${this.getSeverityBadgeClass(inc.severity)}">${inc.severity}</span>
        </div>
        <p class="text-xs text-slate-300 font-medium line-clamp-1">${inc.title}</p>
        <p class="text-[10px] text-slate-500">${inc.location.split(',')[0]} &bull; ${this.formatTimeAgo(inc.timestamp)}</p>
      </div>
    `).join("");

    if (this.incidents.length > 0) this.selectIncidentForGisPanel(this.incidents[0].id);
    if (window.lucide) window.lucide.createIcons();
  }

  selectIncidentForGisPanel(incidentId) {
    const inc = this.incidents.find(i => i.id === incidentId);
    if (!inc) return;

    if (this.homeMap && inc.coordinates) this.homeMap.panTo(inc.coordinates, { animate: true });
    if (this.fullGisMap && inc.coordinates) this.fullGisMap.panTo(inc.coordinates, { animate: true });
    if (this.googleMapInstance && inc.coordinates) this.googleMapInstance.panTo({ lat: inc.coordinates[0], lng: inc.coordinates[1] });

    const panel = document.getElementById("gis-triage-panel");
    if (!panel) return;

    panel.innerHTML = `
      <div class="space-y-4">
        <div class="flex items-center justify-between pb-2 border-b border-slate-800">
          <div>
            <span class="text-[10px] font-mono text-slate-400">${inc.id}</span>
            <h3 class="text-sm font-semibold text-white">${inc.title}</h3>
          </div>
          <span class="badge-clean ${this.getSeverityBadgeClass(inc.severity)}">${inc.severity}</span>
        </div>

        <div class="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
          <div class="flex justify-between text-slate-400"><span>Location:</span> <span class="text-white font-medium">${inc.location}</span></div>
          <div class="flex justify-between text-slate-400"><span>Affected:</span> <span class="text-white font-medium">${inc.peopleAffected}</span></div>
          <div class="flex justify-between text-slate-400"><span>Status:</span> <span class="text-amber-400 font-medium">${inc.status}</span></div>
          <div class="flex justify-between text-slate-400"><span>Reporter:</span> <span class="text-slate-300">${inc.reporterName}</span></div>
        </div>

        <div class="space-y-1.5 text-xs">
          <label class="text-[11px] text-slate-400 font-medium">Update Status</label>
          <select onchange="app.updateIncidentStatus('${inc.id}', this.value)" class="w-full bg-slate-900 border border-slate-700 text-white rounded-lg p-2 text-xs">
            ${STATUS_OPTIONS.map(st => `<option value="${st}" ${inc.status === st ? 'selected' : ''}>${st}</option>`).join("")}
          </select>
        </div>

        <div class="flex space-x-2 pt-2">
          <button onclick="app.showIncidentDetail('${inc.id}')" class="flex-1 py-2 rounded-lg bg-white text-slate-900 hover:bg-slate-100 font-semibold text-xs">
            Full Dossier
          </button>
          <button onclick="app.deleteIncidentPrompt('${inc.id}')" class="px-3 py-2 rounded-lg bg-red-950/40 text-red-400 border border-red-800/50 hover:bg-red-900/50 text-xs">
            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
          </button>
        </div>
      </div>
    `;

    if (window.lucide) window.lucide.createIcons();
  }

  // MAP 3: Report Intake Picker Map
  renderReportForm() {
    this.uploadedPhotoData = null;
    this.aiVerificationResult = null;
    const preview = document.getElementById("photo-preview-container");
    if (preview) preview.innerHTML = "";
    setTimeout(() => this.initReportLocationPicker(), 50);
  }

  initReportLocationPicker() {
    const container = document.getElementById("report-picker-map");
    if (!container) return;

    if (!this.pickerMap) {
      this.pickerMap = L.map("report-picker-map", {
        zoomControl: true,
        attributionControl: false
      }).setView(this.pickerCoords, 14);

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19
      }).addTo(this.pickerMap);

      const pinIcon = L.divIcon({
        className: "custom-marker-wrapper",
        html: `<div class="clean-marker clean-marker-critical"><i data-lucide="map-pin" class="w-3.5 h-3.5"></i></div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });

      this.pickerMarker = L.marker(this.pickerCoords, { draggable: true, icon: pinIcon }).addTo(this.pickerMap);

      this.pickerMarker.on("dragend", (e) => {
        const pos = e.target.getLatLng();
        this.pickerCoords = [pos.lat, pos.lng];
        this.reverseGeocode(pos.lat, pos.lng);
      });

      this.pickerMap.on("click", (e) => {
        const lat = e.latlng.lat;
        const lng = e.latlng.lng;
        this.pickerCoords = [lat, lng];
        this.pickerMarker.setLatLng([lat, lng]);
        this.reverseGeocode(lat, lng);
      });
    } else {
      this.pickerMap.invalidateSize();
      this.pickerMap.setView(this.pickerCoords, 14);
      this.pickerMarker.setLatLng(this.pickerCoords);
    }

    if (window.lucide) window.lucide.createIcons();
  }

  requestLiveGpsLocation() {
    const btn = document.getElementById("btn-get-gps");
    if (btn) btn.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 mr-1.5 animate-spin"></i> Getting GPS...`;
    this.acquireRealtimeGpsLocation();
    setTimeout(() => {
      if (btn) btn.innerHTML = `<i data-lucide="check" class="w-3.5 h-3.5 mr-1.5 text-emerald-400"></i> Locked`;
      if (window.lucide) window.lucide.createIcons();
    }, 1000);
  }

  async reverseGeocode(lat, lng) {
    const locInput = document.getElementById("form-incident-location");
    const nearbyInput = document.getElementById("form-incident-nearby");

    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`);
      if (res.ok) {
        const data = await res.json();
        if (locInput) locInput.value = data.display_name || `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
        const addr = data.address || {};
        const landmark = [addr.road, addr.suburb, addr.city].filter(Boolean).join(", ");
        if (nearbyInput && !nearbyInput.value) nearbyInput.value = landmark ? `Near ${landmark}` : "";
      }
    } catch (e) {
      if (locInput && !locInput.value) locInput.value = `OpenGPS: ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    }
  }

  calculateDynamicSeverity() {
    const category = document.getElementById("form-incident-category")?.value || "Fire Emergency";
    const people = parseInt(document.getElementById("form-incident-people")?.value || "0", 10);
    const desc = (document.getElementById("form-incident-desc")?.value || "").toLowerCase();

    let autoSeverity = "Low";
    if (people >= 5) autoSeverity = "Critical";
    else if (people >= 2) autoSeverity = "High";
    else if (people === 1) autoSeverity = "Medium";

    if (category === "Building Collapse" || (category === "Fire Emergency" && (desc.includes("spread") || desc.includes("explosion") || people > 0))) {
      autoSeverity = "Critical";
    } else if (category === "Flood" && (desc.includes("rising") || desc.includes("roof"))) {
      if (autoSeverity !== "Critical") autoSeverity = "High";
    }

    if (desc.includes("trapped") || desc.includes("chemical") || desc.includes("leak") || desc.includes("unconscious")) {
      autoSeverity = "Critical";
    }

    const badge = document.getElementById("auto-severity-badge");
    const select = document.getElementById("form-incident-severity");

    if (badge) {
      badge.className = `badge-clean ${this.getSeverityBadgeClass(autoSeverity)}`;
      badge.textContent = `Auto-Triage: ${autoSeverity}`;
    }
    if (select) select.value = autoSeverity;
  }

  handlePhotoUpload(file) {
    if (!file) return;

    const preview = document.getElementById("photo-preview-container");
    if (preview) {
      preview.innerHTML = `
        <div class="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs flex items-center space-x-2 text-sky-400">
          <i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i>
          <span>Running AI Image Piracy & Authenticity Scan...</span>
        </div>
      `;
      if (window.lucide) window.lucide.createIcons();
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      this.uploadedPhotoData = e.target.result;

      setTimeout(() => {
        const isStockOrPirated = file.name.toLowerCase().includes("stock") || file.name.toLowerCase().includes("download");
        const authenticityScore = isStockOrPirated ? 42.1 : Number((94 + Math.random() * 5).toFixed(1));
        const status = isStockOrPirated ? "FLAGGED: POTENTIAL PIRACY / REUSED MEDIA" : "AUTHENTICATED ORIGINAL CAPTURE";
        const statusClass = isStockOrPirated ? "text-amber-400" : "text-emerald-400";
        const badgeClass = isStockOrPirated ? "badge-clean-medium" : "badge-clean-low";

        this.aiVerificationResult = {
          score: authenticityScore,
          status,
          piracyMatch: isStockOrPirated ? "Identified in public stock image library" : "0 Copyright / Duplicate Matches Found",
          aiDeepfakeScore: "< 1.8% Synthetic Noise Probability",
          metadataIntegrity: "Natural Bayer Sensor Pattern Verified"
        };

        if (preview) {
          preview.innerHTML = `
            <div class="mt-2 space-y-2 animate-in fade-in">
              <div class="relative inline-block rounded-lg overflow-hidden border border-slate-700">
                <img src="${this.uploadedPhotoData}" class="h-28 w-auto object-cover rounded-lg" />
                <button type="button" onclick="app.removeUploadedPhoto()" class="absolute top-1 right-1 p-1 bg-red-600 text-white rounded-full">
                  <i data-lucide="x" class="w-3 h-3"></i>
                </button>
              </div>

              <div class="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5 text-xs">
                <div class="flex items-center justify-between">
                  <span class="text-[10px] font-mono text-slate-400 uppercase font-semibold">AI Image Authenticity Scan</span>
                  <span class="badge-clean ${badgeClass}">${authenticityScore}% Real</span>
                </div>
                <div class="flex items-center text-xs font-semibold ${statusClass}">
                  <i data-lucide="${isStockOrPirated ? 'alert-triangle' : 'shield-check'}" class="w-3.5 h-3.5 mr-1.5"></i>
                  <span>${status}</span>
                </div>
                <div class="text-[11px] text-slate-400 space-y-0.5 pt-1 border-t border-slate-800">
                  <div>&bull; Piracy / Duplicate Check: <strong class="text-slate-200">${this.aiVerificationResult.piracyMatch}</strong></div>
                  <div>&bull; Deepfake Probability: <strong class="text-slate-200">${this.aiVerificationResult.aiDeepfakeScore}</strong></div>
                  <div>&bull; Forensic Metadata: <strong class="text-slate-200">${this.aiVerificationResult.metadataIntegrity}</strong></div>
                </div>
              </div>
            </div>
          `;
          if (window.lucide) window.lucide.createIcons();
        }
      }, 500);
    };
    reader.readAsDataURL(file);
  }

  removeUploadedPhoto() {
    this.uploadedPhotoData = null;
    this.aiVerificationResult = null;
    const preview = document.getElementById("photo-preview-container");
    if (preview) preview.innerHTML = "";
    const fileInput = document.getElementById("form-incident-photo");
    if (fileInput) fileInput.value = "";
  }

  submitReport(e) {
    e.preventDefault();
    const title = document.getElementById("form-incident-title")?.value.trim();
    const category = document.getElementById("form-incident-category")?.value;
    const severity = document.getElementById("form-incident-severity")?.value;
    const location = document.getElementById("form-incident-location")?.value.trim();
    const nearbyLandmarks = document.getElementById("form-incident-nearby")?.value.trim() || "";
    const peopleAffected = parseInt(document.getElementById("form-incident-people")?.value || "0", 10);
    const description = document.getElementById("form-incident-desc")?.value.trim();
    const reporterName = document.getElementById("form-reporter-name")?.value.trim() || this.currentUser.name;
    const reporterContact = document.getElementById("form-reporter-contact")?.value.trim() || "+1 (555) 019-2831";

    if (!title || !description || !location) {
      alert("Please complete required fields: Title, Description, and Location.");
      return;
    }

    const newIncident = {
      id: `INC-${Math.random().toString(36).substring(2, 8)}`,
      title,
      description,
      category,
      severity,
      status: "Reported",
      location,
      nearbyLandmarks,
      coordinates: [...this.pickerCoords],
      peopleAffected,
      reporterName,
      reporterContact,
      timestamp: new Date().toISOString(),
      photoUrl: this.uploadedPhotoData || "https://images.unsplash.com/photo-1542385151-efd9000785a0?auto=format&fit=crop&w=600&q=80",
      aiProofVerification: this.aiVerificationResult || { status: "Verified Authentic", score: 98.2 },
      assignedUnits: ["Squad Alpha"],
      notes: "Direct report ingested via DisasterX intake."
    };

    this.incidents.unshift(newIncident);
    this.saveIncidents();

    alert(`Incident ${newIncident.id} registered! Transmitted to Command Center.`);
    this.switchView("gis");
    this.selectIncidentForGisPanel(newIncident.id);
  }

  renderAdminStats() {
    const total = this.incidents.length;
    const critical = this.incidents.filter(i => i.severity === "Critical").length;
    const pending = this.incidents.filter(i => i.status === "Pending" || i.status === "Reported").length;
    const resolved = this.incidents.filter(i => i.status === "Resolved").length;

    const elTotal = document.getElementById("stat-total-incidents");
    const elCritical = document.getElementById("stat-critical-incidents");
    const elPending = document.getElementById("stat-pending-incidents");
    const elResolved = document.getElementById("stat-resolved-incidents");

    if (elTotal) elTotal.textContent = total;
    if (elCritical) elCritical.textContent = critical;
    if (elPending) elPending.textContent = pending;
    if (elResolved) elResolved.textContent = resolved;
  }

  renderAdminTable() {
    const tbody = document.getElementById("admin-incidents-tbody");
    if (!tbody) return;

    let filtered = [...this.incidents];
    if (this.filterCategory !== "All") filtered = filtered.filter(i => i.category === this.filterCategory);
    if (this.filterSeverity !== "All") filtered = filtered.filter(i => i.severity === this.filterSeverity);

    tbody.innerHTML = filtered.map(inc => `
      <tr class="border-b border-slate-800/80 hover:bg-slate-900/50 transition">
        <td class="py-2.5 px-3 font-mono text-xs text-slate-400">${inc.id}</td>
        <td class="py-2.5 px-3">
          <div class="font-semibold text-white text-xs">${inc.title}</div>
          <div class="text-[10px] text-slate-400">${inc.location}</div>
        </td>
        <td class="py-2.5 px-3 text-xs text-slate-300">${inc.category}</td>
        <td class="py-2.5 px-3"><span class="badge-clean ${this.getSeverityBadgeClass(inc.severity)}">${inc.severity}</span></td>
        <td class="py-2.5 px-3">
          <select onchange="app.updateIncidentStatus('${inc.id}', this.value)" class="bg-slate-900 border border-slate-700 text-xs rounded px-2 py-1 text-slate-200">
            ${STATUS_OPTIONS.map(st => `<option value="${st}" ${inc.status === st ? 'selected' : ''}>${st}</option>`).join("")}
          </select>
        </td>
        <td class="py-2.5 px-3 text-xs font-mono text-slate-400">${this.formatTimeAgo(inc.timestamp)}</td>
        <td class="py-2.5 px-3 text-right space-x-1.5">
          <button onclick="app.showIncidentDetail('${inc.id}')" class="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300">
            <i data-lucide="eye" class="w-3.5 h-3.5"></i>
          </button>
          <button onclick="app.deleteIncidentPrompt('${inc.id}')" class="p-1 rounded bg-red-950/50 hover:bg-red-900 text-red-400">
            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
          </button>
        </td>
      </tr>
    `).join("");

    if (window.lucide) window.lucide.createIcons();
  }

  updateIncidentStatus(incidentId, newStatus) {
    const inc = this.incidents.find(i => i.id === incidentId);
    if (!inc) return;
    inc.status = newStatus;
    this.saveIncidents();
    if (this.currentView === "admin") {
      this.renderAdminStats();
      this.renderAdminTable();
      this.initDashboardCharts();
    }
  }

  deleteIncidentPrompt(incidentId) {
    if (confirm(`Delete incident record ${incidentId}? (Clears duplicate or test report)`)) {
      this.incidents = this.incidents.filter(i => i.id !== incidentId);
      this.saveIncidents();
      if (this.currentView === "admin") {
        this.renderAdminStats();
        this.renderAdminTable();
        this.initDashboardCharts();
      }
      this.refreshAllMaps();
      this.closeIncidentDetailModal();
    }
  }

  showIncidentDetail(incidentId) {
    const inc = this.incidents.find(i => i.id === incidentId);
    if (!inc) return;

    const modal = document.getElementById("incident-detail-modal");
    if (!modal) return;

    modal.innerHTML = `
      <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="clean-card max-w-lg w-full p-6 border-slate-700 space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <span class="text-[10px] font-mono text-slate-400">${inc.id}</span>
              <h3 class="text-base font-semibold text-white">${inc.title}</h3>
            </div>
            <button onclick="app.closeIncidentDetailModal()" class="text-slate-400 hover:text-white">
              <i data-lucide="x" class="w-5 h-5"></i>
            </button>
          </div>

          ${inc.photoUrl ? `
            <div class="rounded-xl overflow-hidden border border-slate-800 max-h-48 relative">
              <img src="${inc.photoUrl}" class="w-full h-48 object-cover" />
              <div class="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/80 border border-emerald-500/40 text-[10px] text-emerald-400 font-mono">
                AI Authenticity Verified (Clear of Piracy)
              </div>
            </div>
          ` : ''}

          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span class="text-slate-400 text-[10px]">CATEGORY & SEVERITY</span>
              <p class="text-white font-medium mt-0.5">${inc.category} • <span class="${inc.severity === 'Critical' ? 'text-red-400' : 'text-amber-400'}">${inc.severity}</span></p>
            </div>
            <div class="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span class="text-slate-400 text-[10px]">CASUALTIES</span>
              <p class="text-white font-medium mt-0.5">${inc.peopleAffected} persons affected</p>
            </div>
          </div>

          <div class="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs space-y-1">
            <span class="text-slate-400 text-[10px]">INCIDENT NARRATIVE</span>
            <p class="text-slate-300 leading-relaxed">${inc.description}</p>
          </div>

          <div class="pt-2 flex justify-end space-x-2">
            <button onclick="app.closeIncidentDetailModal()" class="btn-pill-white text-xs py-2 px-4">
              Close
            </button>
          </div>
        </div>
      </div>
    `;
    modal.classList.remove("hidden");
    if (window.lucide) window.lucide.createIcons();
  }

  closeIncidentDetailModal() {
    document.getElementById("incident-detail-modal")?.classList.add("hidden");
  }

  initDashboardCharts() {
    const catCanvas = document.getElementById("chart-categories");
    const sevCanvas = document.getElementById("chart-severity");
    if (!window.Chart || !catCanvas || !sevCanvas) return;

    if (this.categoryChart) this.categoryChart.destroy();
    if (this.severityChart) this.severityChart.destroy();

    const catCounts = EMERGENCY_CATEGORIES.map(c => this.incidents.filter(i => i.category === c.id).length);
    this.categoryChart = new Chart(catCanvas, {
      type: "doughnut",
      data: {
        labels: EMERGENCY_CATEGORIES.map(c => c.name),
        datasets: [{
          data: catCounts,
          backgroundColor: ["#EF4444", "#F97316", "#EC4899", "#06B6D4", "#8B5CF6", "#F59E0B"],
          borderWidth: 2,
          borderColor: "#0B1120"
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "bottom", labels: { color: "#94A3B8", boxWidth: 10, font: { size: 10 } } } }
      }
    });

    const sevLabels = ["Low", "Medium", "High", "Critical"];
    const sevCounts = sevLabels.map(s => this.incidents.filter(i => i.severity === s).length);
    this.severityChart = new Chart(sevCanvas, {
      type: "bar",
      data: {
        labels: sevLabels,
        datasets: [{
          data: sevCounts,
          backgroundColor: ["#10B981", "#F59E0B", "#F97316", "#EF4444"],
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        scales: {
          x: { ticks: { color: "#94A3B8" }, grid: { display: false } },
          y: { ticks: { color: "#94A3B8", stepSize: 1 }, grid: { color: "#1E293B" } }
        },
        plugins: { legend: { display: false } }
      }
    });
  }

  quickFilterByCategory(catId) {
    this.filterCategory = catId;
    this.switchView("admin");
    const select = document.getElementById("admin-filter-category");
    if (select) select.value = catId;
  }

  // Floating AI logic
  initFloatingAi() {
    const input = document.getElementById("floating-ai-input");
    const sendBtn = document.getElementById("floating-ai-send");
    if (input && sendBtn) {
      const handleSend = () => {
        const text = input.value.trim();
        if (!text) return;
        this.appendAiMessage("user", text);
        input.value = "";

        setTimeout(() => {
          const res = window.rescueMate.respond(text);
          if (res.type === "protocol") {
            const steps = res.data.steps.map((s, i) => `<div class="mb-1"><strong>${i+1}.</strong> ${s}</div>`).join("");
            this.appendAiMessage("ai", `<div><div class="font-bold text-sky-400 text-xs mb-1">${res.data.title}</div>${steps}</div>`);
          } else if (res.type === "triage") {
            this.appendAiMessage("ai", `
              <div>
                <p class="text-xs mb-2">${res.reply}</p>
                <button onclick="app.autoFillReportFromAi(${JSON.stringify(res.triageData).replace(/"/g, '&quot;')})" class="btn-pill-white text-[11px] py-1 px-3">
                  Populate Report Form
                </button>
              </div>
            `);
          } else {
            this.appendAiMessage("ai", `<p class="text-xs">${res.reply.replace(/\n/g, '<br/>')}</p>`);
          }
        }, 150);
      };

      sendBtn.addEventListener("click", handleSend);
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") handleSend(); });
    }
  }

  appendAiMessage(sender, html) {
    const body = document.getElementById("floating-ai-messages");
    if (!body) return;
    const div = document.createElement("div");
    div.className = `flex ${sender === 'user' ? 'justify-end' : 'justify-start'}`;
    div.innerHTML = `<div class="max-w-[85%] p-3 rounded-xl text-xs ${sender === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-200 border border-slate-700'}">${html}</div>`;
    body.appendChild(div);
    body.scrollTop = body.scrollHeight;
  }

  toggleFloatingAi() {
    document.getElementById("floating-ai-window")?.classList.toggle("hidden");
  }

  askAiPrompt(text) {
    const win = document.getElementById("floating-ai-window");
    if (win && win.classList.contains("hidden")) win.classList.remove("hidden");
    const input = document.getElementById("floating-ai-input");
    if (input) {
      input.value = text;
      document.getElementById("floating-ai-send")?.click();
    }
  }

  autoFillReportFromAi(data) {
    this.switchView("report");
    this.toggleFloatingAi();
    setTimeout(() => {
      if (document.getElementById("form-incident-title")) document.getElementById("form-incident-title").value = data.title;
      if (document.getElementById("form-incident-category")) document.getElementById("form-incident-category").value = data.category;
      if (document.getElementById("form-incident-severity")) document.getElementById("form-incident-severity").value = data.severity;
      if (document.getElementById("form-incident-people")) document.getElementById("form-incident-people").value = data.peopleAffected;
      if (document.getElementById("form-incident-desc")) document.getElementById("form-incident-desc").value = data.description;
      if (data.suggestedLocation && document.getElementById("form-incident-location")) document.getElementById("form-incident-location").value = data.suggestedLocation;
      this.calculateDynamicSeverity();
    }, 100);
  }

  openLoginModal(tab = "signin") {
    document.getElementById("login-modal")?.classList.remove("hidden");
    this.switchAuthTab(tab);
  }

  closeLoginModal() {
    document.getElementById("login-modal")?.classList.add("hidden");
  }

  switchAuthTab(tab) {
    const tabSignIn = document.getElementById("auth-tab-signin");
    const tabSignUp = document.getElementById("auth-tab-signup");
    const tabAdmin = document.getElementById("auth-tab-admin");

    const contentSignIn = document.getElementById("auth-content-signin");
    const contentSignUp = document.getElementById("auth-content-signup");
    const contentAdmin = document.getElementById("auth-content-admin");

    [contentSignIn, contentSignUp, contentAdmin].forEach(el => el?.classList.add("hidden"));
    [tabSignIn, tabSignUp, tabAdmin].forEach(el => {
      el?.classList.remove("text-white", "border-b-2", "border-blue-500");
      el?.classList.add("text-slate-400");
    });

    if (tab === "signin") {
      contentSignIn?.classList.remove("hidden");
      tabSignIn?.classList.add("text-white", "border-b-2", "border-blue-500");
    } else if (tab === "signup") {
      contentSignUp?.classList.remove("hidden");
      tabSignUp?.classList.add("text-white", "border-b-2", "border-blue-500");
    } else if (tab === "admin") {
      contentAdmin?.classList.remove("hidden");
      tabAdmin?.classList.add("text-white", "border-b-2", "border-blue-500");
    }
  }

  handleUserSignIn(e) {
    e.preventDefault();
    const email = document.getElementById("signin-email")?.value;
    this.userRole = "citizen";
    this.currentUser = { name: email.split("@")[0] || "Citizen User", email: email, role: "citizen" };
    this.updateUserSessionUI();
    this.closeLoginModal();
    alert(`Signed in as ${this.currentUser.name} (Citizen Reporter)`);
  }

  handleUserSignUp(e) {
    e.preventDefault();
    const name = document.getElementById("signup-name")?.value;
    const email = document.getElementById("signup-email")?.value;
    this.userRole = "citizen";
    this.currentUser = { name: name || "New Reporter", email: email, role: "citizen" };
    this.updateUserSessionUI();
    this.closeLoginModal();
    alert(`Account created! Welcome, ${this.currentUser.name}`);
  }

  handleAdminLogin(e) {
    e.preventDefault();
    this.userRole = "admin";
    this.currentUser = { name: "Commander Krishna", email: "admin@disasterx.org", role: "admin" };
    this.updateUserSessionUI();
    this.closeLoginModal();
    alert(`Authenticated as Emergency Command Administrator (Full ECC Access)`);
  }

  quickAdminFill() {
    if (document.getElementById("admin-login-email")) document.getElementById("admin-login-email").value = "admin@disasterx.org";
    if (document.getElementById("admin-login-password")) document.getElementById("admin-login-password").value = "admin123";
  }

  updateUserSessionUI() {
    const badge = document.getElementById("user-session-badge");
    const footerBtn = document.getElementById("footer-login-btn");
    if (badge) {
      badge.innerHTML = `
        <span class="w-1.5 h-1.5 rounded-full ${this.userRole === 'admin' ? 'bg-sky-400' : 'bg-emerald-400'} animate-pulse inline-block mr-1.5"></span>
        <span>${this.currentUser.name}</span>
        <span class="text-[9px] px-1 py-0.2 rounded bg-slate-800 ml-1 text-slate-300 font-mono">${this.userRole.toUpperCase()}</span>
      `;
    }
    if (footerBtn) {
      footerBtn.innerHTML = `<span>Session: ${this.currentUser.name} (${this.userRole})</span>`;
    }
  }

  toggleMobileMenu() {
    document.getElementById("mobile-menu")?.classList.toggle("hidden");
  }

  bindEvents() {
    document.getElementById("emergency-report-form")?.addEventListener("submit", (e) => this.submitReport(e));

    const desc = document.getElementById("form-incident-desc");
    const people = document.getElementById("form-incident-people");
    const category = document.getElementById("form-incident-category");
    [desc, people, category].forEach(el => {
      if (el) {
        el.addEventListener("input", () => this.calculateDynamicSeverity());
        el.addEventListener("change", () => this.calculateDynamicSeverity());
      }
    });

    const fileInput = document.getElementById("form-incident-photo");
    if (fileInput) {
      fileInput.addEventListener("change", (e) => {
        if (e.target.files && e.target.files[0]) this.handlePhotoUpload(e.target.files[0]);
      });
    }

    const filterCat = document.getElementById("admin-filter-category");
    if (filterCat) filterCat.addEventListener("change", (e) => { this.filterCategory = e.target.value; this.renderAdminTable(); });
    const filterSev = document.getElementById("admin-filter-severity");
    if (filterSev) filterSev.addEventListener("change", (e) => { this.filterSeverity = e.target.value; this.renderAdminTable(); });
  }
}

window.app = new DisasterXApp();
