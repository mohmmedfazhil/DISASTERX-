# DisasterX - Emergency Response & Disaster Management Platform
> **TAGLINE: DETECT • RESPOND • PROTECT**  
> *Code Clash 2026 — Round 1: Emergency Incident Reporting & Monitoring Submission*

---

## 🔗 Design System & Architecture Links
- **Figma UI/UX Design File**: [DisasterX UI/UX Design](https://www.figma.com/design/kOKye4WFTWmR9l0NLAsuCu)
- **FigJam Architecture & UX Flowchart**: [DisasterX UI UX Workflow](https://www.figma.com/board/FAghO5kQuYFpvdfuBJmlh8)

---

## 🎯 Executive Summary
**DisasterX** is an autonomous emergency response and disaster coordination platform built to eliminate communication latency during critical events such as fires, multi-vehicle crashes, flash floods, and building collapses.

The system connects reporting citizens, field observers, and municipal dispatchers through an integrated **OpenGPS (GIS)** geospatial engine, automated severity triage classifier, and **Rescue mate AI** guidance.

---

## 🏆 Code Clash 2026 Round 1 Feature Compliance

| Round 1 Required Feature | Requirement Specification | DisasterX Implementation Status |
| :--- | :--- | :--- |
| **1. Emergency Incident Reporting** | Form capturing Title, Description, Category, Location, Casualties, Optional Contact Info, and Photo Proof | ✅ **100% Complete** — Interactive multi-step form with HTML5 OpenGPS coordinate locking, address reverse-geocoding, and drag-and-drop photo proof preview. |
| **2. Emergency Categories** | Support 6 standard disaster categories: Fire, Road Accident, Medical, Flood, Building Collapse, Other | ✅ **100% Complete** — Full category taxonomy with distinct iconography, color coding, and triage priorities. |
| **3. Incident Severity Classification** | Implement a logical mechanism to classify incidents into Low, Medium, High, and Critical | ✅ **100% Complete** — Rule-based algorithmic scoring evaluating casualty counts, disaster category, and hazard keywords (e.g. "explosion", "trapped", "toxic") with manual override. |
| **4. Emergency Dashboard** | Administrative dashboard displaying Total, Critical, Pending, Resolved incidents, and Incidents by Category | ✅ **100% Complete** — Real-time KPI counter cards + Chart.js interactive doughnut and bar visual charts. |
| **5. Incident Management** | View all reports, inspect individual details, update status (Reported, Pending, In Progress, Resolved), and delete test/duplicate reports | ✅ **100% Complete** — Command center split queue, full dossier detail modals, inline status updater, and confirmation delete mechanism. |
| **6. Professional UI/UX** | Dark navy-blue theme, red emergency accents, cyan highlights, modern dashboard cards, responsive layout | ✅ **100% Complete** — Styled exactly according to prompt specs (`#070C18`, `#00D2FF`, `#EF4444`, `#F59E0B`, `#10B981`) with glassmorphism and pulsing beacons. |

---

## 🎨 Color Palette & Design Tokens
As provided in the challenge specifications:
- **Background**: Dark Navy (`#070C18` / `#091122`)
- **Primary**: Electric Blue / Cyan (`#0066FF` / `#00D2FF` / `#38BDF8`)
- **Emergency Accent**: Red (`#EF4444` / `#DC2626`)
- **Warning**: Orange / Amber (`#F59E0B` / `#F97316`)
- **Success**: Green (`#10B981`)
- **Cards**: Dark Navy Glassmorphism (`#0F1A30` with border `#1E2D4E`)

---

## 🤖 Rescue mate AI (Emergency Companion)
- **Conversational Assistant**: Floating persistent 24/7 emergency chatbot.
- **Smart Triage Auto-Filler**: Type or paste any plain-language incident description, and Rescue mate AI automatically extracts the Category, Severity, Estimated Casualties, and Location, with a 1-click button to auto-fill the intake form.
- **Life-Saving Protocols**: Instant first-aid instructions for CPR, Severe Bleeding & Tourniquets, Fire/Smoke evacuation, Flash flood survival, and Building collapse safety.
- **Voice Readout**: Web Speech API integration for hands-free audio guidance in the field.

---

## 📍 OpenGPS (GIS) Real-Time Geospatial System
- **Real-Time GPS Location Detection**: Browser Geolocation API locks device coordinates with meter-level accuracy.
- **Reverse Geocoding**: Automatic Nominatim OpenStreetMap translation of coordinates into street addresses and nearby landmarks.
- **Interactive Leaflet Map**: Draggable emergency beacon marker on reporting form, and full multi-layer Command Center map with danger zone polygons and custom category pins.

---

## 🔐 Footer Requirements
- **Prominent Tagline**: `DETECT • RESPOND • PROTECT` prominently featured in the footer header and hero strip.
- **Login / Sign In Option**: Accessible directly from the footer button (`Login / Sign In (Admin & Citizen)`), allowing instant switching between Citizen Reporter and ECC Administrator roles with pre-filled demo credentials.

---

## 🚀 How to Run
This is a self-contained zero-dependency web application.
1. Open `index.html` directly in any modern browser (Chrome, Edge, Safari, Firefox), or run:
   ```bash
   open index.html
   ```
2. Data automatically persists in `localStorage` across page refreshes.
